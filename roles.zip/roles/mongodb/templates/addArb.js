{% for host in groups['arbiter'] %}
rs.addArb("{{ host }}:{{ mongod_port }}")
sleep(300)
{% endfor %}
