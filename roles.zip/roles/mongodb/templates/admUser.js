use admin
db.createUser({user:'root',pwd:'{{ mongopassword }}',roles:['root']})
db.createUser({user:'backupUser',pwd:'{{ backuppassword }}',roles:['root']})
db.createUser({user:'icinga',pwd:'0879301a-9284-11e9-bc42-526af7764f64',roles:[ { role:'readAnyDatabase',db:'admin'},{role:'clusterMonitor',db:'admin'},{role:'readWrite',db:'nagios'}]})

