{% for host in groups['secondary'] %}
rs.add("{{ host }}:{{ mongod_port }}")
sleep(300)
{% endfor %}
printjson(rs.status())
