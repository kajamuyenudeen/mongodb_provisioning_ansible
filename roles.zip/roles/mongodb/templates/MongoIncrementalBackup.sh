#!/bin/bash

Dt=`date +"%d-%m-%Y"`
BckPath=/backup/$Dt

##########Creating a Full Backup###########
for dbname in `df -h | grep -i "log" | awk '{print $6}' | cut -d "_" -f2`
do
  mkdir -p $BckPath/$dbname/Incremental
  BackupLog=$BckPath/$dbname/Incremental/MongoBackupLog.txt
  date >> $BackupLog 2>&1
  confFile=`ps -ef | grep $dbname | grep -v "grep" | awk '{print $10}'`
  h=`cat $confFile  |grep bind | grep -v "#" | cut -d : -f2`

#/usr/bin/mongodump -u backupUser -p'22bef5fa-80ea-11e9-bc42-526af7764f64' --authenticationDatabase=admin --host $h --port 28017 --archive=$BckPath/$dbname/FullBackup/FullBack_$Dt.gz --gzip --oplog >> $BackupLog 2>&1

########Creating an Incremental Backup##############
/usr/bin/mongodump -u backupUser -p'{{ backuppassword }}' --authenticationDatabase=admin --host $h -d local -c oplog.rs --port 28017 -o $BckPath/$dbname/Incremental --gzip  >> $BackupLog 2>&1

if [ $?==0 ]; then
    echo "Backup is done successfully on host $h" >> $BackupLog 2>&1
    #send mail with BackupLog file $BackupLog as an attachment

else
   echo "Backup failed on host $h" >> $BackupLog 2>&1
   #send mail with BackupLog file $BackupLog as an attachment
fi
done
