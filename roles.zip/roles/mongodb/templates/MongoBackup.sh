#!/bin/bash

Dt=`date +"%d-%m-%Y"`
oldDt=`date --date="3 days ago" +"%d-%m-%Y"`

#Check if Backup Directory exists
if [ ! -d "/backup" ]; then
    mkdir -p /backup
fi

mkdir -p /backup/$Dt
BckPath=/backup/$Dt

#####check and delete 3 days old backup######
cd $BckPath
rm -rf $oldDt

##########Creating a Full Backup###########
for dbname in `df -h | grep -i "log" | awk '{print $6}' | cut -d "_" -f2`
do
  mkdir -p $BckPath/$dbname/FullBackup
  BackupLog=$BckPath/$dbname/FullBackup/MongoBackupLog.txt
  date >> $BackupLog 2>&1
  confFile=`ps -ef | grep $dbname | grep -v "grep" | awk '{print $10}'`
  h=`cat $confFile  |grep bind | grep -v "#" | cut -d : -f2`

/usr/bin/mongodump -u backupUser -p'{{ backuppassword}}' --authenticationDatabase=admin --host $h --port 28017 --archive=$BckPath/$dbname/FullBackup/FullBack_$Dt.gz --gzip --oplog >> $BackupLog 2>&1

if [ $?==0 ]; then
    echo "Backup is done successfully on host $h" >> $BackupLog 2>&1
    #send mail with BackupLog file $BackupLog as an attachment

else
   echo "Backup failed on host $h" >> $BackupLog 2>&1
   #send mail with BackupLog file $BackupLog as an attachment
fi

#####Copy Mongodb Configuration File#######
cp $confFile $BckPath/$dbname

done
