#!/bin/bash

##Mongodb Log Rotation#######
for dbname in `df -h | grep -i "log" | awk '{print $6}' | cut -d "_" -f2`
do
    confFile=`ps -ef | grep $dbname | grep -v "grep" | awk '{print $10}'`
	h=`cat $confFile  |grep bind | grep -v "#" | cut -d : -f2`
    mongo admin -u root -p'{{mongopassword}}' --host $h  --port 28017 --eval "db.adminCommand({logRotate:1})"
done

for mp in `df -h | grep -i "log" | awk '{print $6}'`
do
   for f in  $mp/mongod.log.????-??-??T??-??-??;
   do
        tar -vcf "$f.tar.gz" "$f"
        rm -f "$f"
   done

   find  $mp/mongod.log.????-??-??T??-??-??.tar.gz -ctime +7 -delete

done
